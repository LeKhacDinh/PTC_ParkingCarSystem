#ifndef Utils_class_h
#define Utils_class_h
#include <Arduino.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "SPIFFS.h"

class Utils
{
public:
    Utils();

    static String byteToHex(byte* data, size_t len) {
        // Create a string to hold the hex representation
        String hexString = "";

        // Loop through each byte in the array
        for (size_t i = 0; i < len; i++) {
            if(data[i] < 0x10) {
            hexString += '0';
            }

            // Convert the byte to a hexadecimal string using two digits (zero-padded)
            hexString += String(data[i], HEX);
        }

        // Return the final hex string
        return hexString;
    }

    // Function to convert an integer to a JSON-formatted string
    static String intToString(int number) {
        char buffer[20]; // Buffer to hold the JSON string
        snprintf(buffer, sizeof(buffer), "%d", number);
        return String(buffer);
    }

    // Function to convert a float to a JSON-formatted string
    static String floatToString(float number) {
        char buffer[30]; // Buffer to hold the JSON string
        snprintf(buffer, sizeof(buffer), "%.6f", number); // Adjust precision as needed
        return String(buffer);
    }

    static void parseIPString(String ipString, int parts[4]) {
        int index = 0;
        int startIndex = 0;
        int endIndex = ipString.indexOf('.');

        for (int i = 0; i < 4; i++) {
            if (endIndex == -1) {
                parts[i] = ipString.substring(startIndex).toInt();
            } else {
                parts[i] = ipString.substring(startIndex, endIndex).toInt();
                startIndex = endIndex + 1;
                endIndex = ipString.indexOf('.', startIndex);
            }
        }
    }

    static String readFile(const String& path) {
        File file = SPIFFS.open(path, "r");
        if (!file) {
            Serial.println("Failed to open file for reading");
            return "";
        }

        String content = file.readString();
        file.close();
        return content;
    }
};

#endif  // Utils_class_h