#ifndef Config_class_h
#define Config_class_h
#include <Arduino.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define BOOT_MODE_ACCESSPOINT       1
#define BOOT_MODE_NORMAL            2
#define BOOT_MODE_UPDATE_FW         3
#define BOOT_MODE_UPDATE_FILESYSTEM 4

#define WEB_SERVER_PORT            80
#define MAX_LENGTH_INIT_STATE      1
#define MAX_LENGTH_BOOT_MODE       1
#define MAX_LENGTH_SSID            20
#define MAX_LENGTH_PASSWORD        32
#define MAX_LENGTH_MIN_DISTANCE    4 
#define MAX_LENGTH_MAX_DISTANCE    4 
#define MAX_LENGTH_LOGIN_ID        20
#define MAX_LENGTH_LOGIN_PASSWORD  32
#define MAX_LENGTH_DEVICE_ID       20 
#define MAX_LENGTH_DEVICE_NAME     255
#define MAX_LENGTH_IP_TYPE         1
#define MAX_LENGTH_IP              20
#define MAX_LENGTH_GATEWAY          20
#define MAX_LENGTH_SUBNETMASK       20

#define MAX_LENGTH_WIFI_ROUTER_NAME 40
#define MAX_LENGTH_WIFI_ROUTER_IP   20
#define MAX_LENGTH_WIFI_ROUTER_PASSWORD  32
#define MAX_LENGTH_WIFI_ROUTER_GATEWAY          20
#define MAX_LENGTH_WIFI_ROUTER_SUBNETMASK       20

#define MAX_LENGTH_MAX_MINUTE       4
#define MAX_LENGTH_CUR_DISTANCE     4
#define MAX_LENGTH_CO_XE            1
#define MAX_LENGTH_TG_DAU_XE        4
#define MAX_LENGTH_CANH_BAO         1
#define MAX_LENGTH_TG_KET_THUC_DAU_XE  4
#define MAX_LENGTH_HISTORY          20480
#define MAX_LENGTH_HISTORY_DATE     10 //dd/MM/yyyy
#define MAX_LENGTH_SO_PHUT_DAU_XE   4


//for test
#define MAX_LENGTH_TEST_TYPE        1

#define MAX_LENGTH_MAX_WAIT_SECONDS 4



#define ADDRESS_INIT_STATE      0                                                       //max 1 char
#define ADDRESS_BOOT_MODE       ADDRESS_INIT_STATE + MAX_LENGTH_INIT_STATE + 1          //max 1 char
#define ADDRESS_SSID            ADDRESS_BOOT_MODE + MAX_LENGTH_BOOT_MODE + 1            //max 20 char
#define ADDRESS_PASSWORD        ADDRESS_SSID + MAX_LENGTH_SSID + 1                      //max 32 char

#define ADDRESS_MIN_DISTANCE    ADDRESS_PASSWORD + MAX_LENGTH_PASSWORD + 1          //max 4 char
#define ADDRESS_MAX_DISTANCE    ADDRESS_MIN_DISTANCE + MAX_LENGTH_MIN_DISTANCE + 1      //max 4 char

#define ADDRESS_LOGIN_ID        ADDRESS_MAX_DISTANCE + MAX_LENGTH_MAX_DISTANCE + 1      //max 20 char
#define ADDRESS_LOGIN_PASSWORD   ADDRESS_LOGIN_ID + MAX_LENGTH_LOGIN_ID + 1             //max 32 char

#define ADDRESS_IP_TYPE         ADDRESS_LOGIN_PASSWORD + MAX_LENGTH_LOGIN_PASSWORD + 1  //max 1 char
#define ADDRESS_IP              ADDRESS_IP_TYPE + MAX_LENGTH_IP_TYPE + 1                //max 20 char
#define ADDRESS_GATEWAY         ADDRESS_IP + MAX_LENGTH_IP + 1                          //max 20 char
#define ADDRESS_SUBNETMASK      ADDRESS_GATEWAY + MAX_LENGTH_GATEWAY + 1                //max 20 char

#define ADDRESS_DEVICE_NAME     ADDRESS_SUBNETMASK + MAX_LENGTH_SUBNETMASK + 1          //max 255 char
#define ADDRESS_DEVICE_ID       ADDRESS_DEVICE_NAME + MAX_LENGTH_DEVICE_NAME + 1        //max 20 char


#define ADDRESS_WIFI_ROUTER_NAME        ADDRESS_DEVICE_ID + MAX_LENGTH_DEVICE_ID + 1                //max 40 char
#define ADDRESS_WIFI_ROUTER_IP          ADDRESS_WIFI_ROUTER_NAME + MAX_LENGTH_WIFI_ROUTER_NAME + 1  //max 20 char
#define ADDRESS_WIFI_ROUTER_PASSWORD    ADDRESS_WIFI_ROUTER_IP + MAX_LENGTH_WIFI_ROUTER_IP + 1      //max 32 char
#define ADDRESS_WIFI_ROUTER_GATEWAY     ADDRESS_WIFI_ROUTER_PASSWORD + MAX_LENGTH_WIFI_ROUTER_PASSWORD + 1                //max 32 char
#define ADDRESS_WIFI_ROUTER_SUBNETMASK  ADDRESS_WIFI_ROUTER_GATEWAY + MAX_LENGTH_WIFI_ROUTER_GATEWAY + 1                  //max 32 char

#define ADDRESS_MAX_MINUTE              ADDRESS_WIFI_ROUTER_SUBNETMASK + MAX_LENGTH_WIFI_ROUTER_SUBNETMASK + 1                  //max 4 char

#define ADDRESS_CUR_DISTANCE            ADDRESS_MAX_MINUTE + MAX_LENGTH_MAX_MINUTE + 1
#define ADDRESS_CO_XE                   ADDRESS_CUR_DISTANCE + MAX_LENGTH_CUR_DISTANCE + 1
#define ADDRESS_TG_DAU_XE               ADDRESS_CO_XE + MAX_LENGTH_CO_XE + 1
#define ADDRESS_CANH_BAO                ADDRESS_TG_DAU_XE + MAX_LENGTH_TG_DAU_XE + 1
#define ADDRESS_TG_KET_THUC_DAU_XE      ADDRESS_CANH_BAO + MAX_LENGTH_CANH_BAO + 1


#define ADDRESS_HISTORY                 ADDRESS_TG_KET_THUC_DAU_XE + MAX_LENGTH_TG_KET_THUC_DAU_XE + 1
#define ADDRESS_HISTORY_DATE            ADDRESS_HISTORY + MAX_LENGTH_HISTORY + 1

#define ADDRESS_SO_PHUT_DAU_XE          ADDRESS_HISTORY_DATE + MAX_LENGTH_HISTORY_DATE + 1

#define ADDRESS_TEST_TYPE               ADDRESS_SO_PHUT_DAU_XE + MAX_LENGTH_SO_PHUT_DAU_XE + 1

#define ADDRESS_MAX_WAIT_SECONDS        ADDRESS_TEST_TYPE + MAX_LENGTH_TEST_TYPE + 1
#define EEPROM_INITIALIZED 1

#define STASSID "247474"
#define STAPSK "247474llq"

#define AP_SSID "GMC WIFI Device"
#define AP_PASWORD "abcD@1234!"
#define AP_IP_ADDRESS "192.168.69.70"
#define AP_GATEWAY "192.168.69.1"
#define AP_SUBNETMASK "255.255.255.0"

#define IP_TYPE_DHCP 0
#define IP_TYPE_MANUAL 1

class Config
{
public:
    Config();
    void init();

    String getSSID();
    void setSSID(String ssid);

    String getPassword();
    void setPassword(String password);

    int getBootMode();
    void setBootMode(int boot_mode);

    int getMinDistance();
    void setMinDistance(int minDistance);

    int getMaxDistance();
    void setMaxDistance(int maxDistance);

    int getMaxMinute();
    void setMaxMinute(int maxMinute);

    int getMaxWaitSeconds();
    void setMaxWaitSeconds(int maxWaitSeconds);

    String getLoginId();
    void setLoginId(String loginId);

    String getLoginPassword();
    void setLoginPassword(String loginPassword);

    String getDeviceId();
    void setDeviceId(String device_id);

    String getDeviceName();
    void setDeviceName(String device_name);

    int getIpType();
    void setIpType(int ipType);

    String getIp();
    void setIp(String ip);

    String getGateway();
    void setGateway(String gateway);

    String getSubnetMask();
    void setSubnetMask(String subnetMask);

    String getWifiRouterName();
    void setWifiRouterName(String wifiRouterName);
    String getWifiRouterIp();
    void setWifiRouterIp(String wifiRouterIp);
    String getWifiRouterPassword();
    void setWifiRouterPassword(String wifiRouterPassword);
    String getWifiRouterGateway();
    void setWifiRouterGateway(String wifiRouterGateway);
    String getWifiRouterSubnetmask();
    void setWifiRouterSubnetmask(String wifiRouterSubnetmask);

    void setInitialized();
    void clearEEPROM();
    String readStringFromEEPROM(int address);
    void writeStringToEEPROM(int address, const String& data);
    int readIntFromEEPROM(int address);
    void writeIntToEEPROM(int address, int data);
    long readLongFromEEPROM(long address);
    void writeLongToEEPROM(int address, long data);
    int getCurDistance();
    void setCurDistance(int curDistance);

    int getCoXe();
    void setCoXe(int coXe);

    int getTgBatDauDauXe();
    void setTgBatDauDauXe(int tg_dau_xe);

    int getTgKetThucDauXe();
    void setTgKetThucDauXe(int tg_ket_thuc_dau_xe);

    int getSoPhutDauXe();
    void setSoPhutDauXe(int cosoPhutDauXe);

    int getCanhBao();
    void setCanhBao(int canhBao);

    String getHistory();
    void addHistory(String date, String text);
    void clearHistory();

    String getHistoryDate();
    void setHistoryDate(String date);
    
    int getTest();
    void setTest(int test);
private:
    void resetEEPROM();
    int getParamMaxLength(int address);
};

#endif  // Config_class_h