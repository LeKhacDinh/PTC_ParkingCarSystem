#include "config.h"
#include <Preferences.h>

#define NVS_NAMESPACE "config"

Config::Config()
{
}

void Config::init(){
    Serial.println("init: ");
    Serial.print("INIT_STATE :");
    Serial.println(readStringFromEEPROM(ADDRESS_INIT_STATE));
    if(readStringFromEEPROM(ADDRESS_INIT_STATE) != String(EEPROM_INITIALIZED)){
        Serial.println("resetEEPROM: ");
        resetEEPROM();
    }
}

void Config::resetEEPROM(){
    writeStringToEEPROM(ADDRESS_BOOT_MODE, String(BOOT_MODE_ACCESSPOINT));
    writeStringToEEPROM(ADDRESS_SSID, STASSID);
    writeStringToEEPROM(ADDRESS_PASSWORD, STAPSK);

    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_NAME, AP_SSID);
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_IP, AP_IP_ADDRESS);
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_GATEWAY, AP_GATEWAY);
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_SUBNETMASK, AP_SUBNETMASK);
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_PASSWORD, AP_PASWORD);
}

void Config::setInitialized(){
    Serial.print("INIT_STATE :");
    Serial.println(readStringFromEEPROM(ADDRESS_INIT_STATE));

    Serial.print("EEPROM_INITIALIZED :");
    Serial.println(String(EEPROM_INITIALIZED));
    writeIntToEEPROM(ADDRESS_INIT_STATE, EEPROM_INITIALIZED);

    Serial.print("INIT_STATE :");
    Serial.println(readStringFromEEPROM(ADDRESS_INIT_STATE));
}

String Config::getSSID()
{
    return readStringFromEEPROM(ADDRESS_SSID);
}

void Config::setSSID(String ssid)
{
    writeStringToEEPROM(ADDRESS_SSID, ssid);
}

String Config::getPassword(){
    return readStringFromEEPROM(ADDRESS_PASSWORD);
}

void Config::setPassword(String password){
    writeStringToEEPROM(ADDRESS_PASSWORD, password);
}



int Config::getBootMode(){
    return readIntFromEEPROM(ADDRESS_BOOT_MODE);
}

void Config::setBootMode(int boot_mode){
    writeIntToEEPROM(ADDRESS_BOOT_MODE, boot_mode);
}

void Config::clearEEPROM(){
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false);
    preferences.clear(); // Xóa toàn bộ dữ liệu trong NVS
    preferences.end();
}

void Config::writeStringToEEPROM(int address, const String &data)
{
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false);
    preferences.putString(String(address).c_str(), data);
    preferences.end();
}

String Config::readStringFromEEPROM(int address)
{
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false); // Mở NVS với tên namespace là "config"
    String value = preferences.getString(String(address).c_str(), "");
    preferences.end();
    return value;
}

int Config::getParamMaxLength(int address){
    int maxLength = 255; //4K eeprom
    switch(address){
        case ADDRESS_INIT_STATE:
            maxLength =MAX_LENGTH_INIT_STATE;
            break;
        case ADDRESS_BOOT_MODE:
            maxLength =MAX_LENGTH_BOOT_MODE;
            break;
        case ADDRESS_SSID:
            maxLength =MAX_LENGTH_SSID;
            break;
        case ADDRESS_PASSWORD:
            maxLength =MAX_LENGTH_PASSWORD;
            break;
        case ADDRESS_MIN_DISTANCE:
            maxLength =MAX_LENGTH_MIN_DISTANCE;
            break;
        case ADDRESS_MAX_DISTANCE:
            maxLength =MAX_LENGTH_MAX_DISTANCE;
            break;
    }
    return maxLength;
}

int Config::getMinDistance(){
    //m_min_distance = readIntFromEEPROM(ADDRESS_MIN_DISTANCE);
    return readIntFromEEPROM(ADDRESS_MIN_DISTANCE);
}
void Config::setMinDistance(int minDistance){
    //m_min_distance = minDistance;
    writeIntToEEPROM(ADDRESS_MIN_DISTANCE, minDistance);
}

int Config::getMaxDistance(){
    //m_max_distance = readStringFromEEPROM(ADDRESS_MAX_DISTANCE);
    return readIntFromEEPROM(ADDRESS_MAX_DISTANCE);
}
void Config::setMaxDistance(int maxDistance){
    //m_max_distance = maxDistance;
    writeIntToEEPROM(ADDRESS_MAX_DISTANCE, maxDistance);
}

int Config::getMaxMinute(){
    return readIntFromEEPROM(ADDRESS_MAX_MINUTE);
}
void Config::setMaxMinute(int maxMinute){
    writeIntToEEPROM(ADDRESS_MAX_MINUTE, maxMinute);
}

int Config::getMaxWaitSeconds(){
    return readIntFromEEPROM(ADDRESS_MAX_WAIT_SECONDS);
}
void Config::setMaxWaitSeconds(int maxWaitSeconds){
    writeIntToEEPROM(ADDRESS_MAX_WAIT_SECONDS, maxWaitSeconds);
}

String Config::getLoginId(){
    return readStringFromEEPROM(ADDRESS_LOGIN_ID);
}
void Config::setLoginId(String login_id)
{
    writeStringToEEPROM(ADDRESS_LOGIN_ID, login_id);
}

String Config::getLoginPassword(){
    return readStringFromEEPROM(ADDRESS_LOGIN_PASSWORD);
}
void Config::setLoginPassword(String login_password)
{
    writeStringToEEPROM(ADDRESS_LOGIN_PASSWORD, login_password);
}

String Config::getDeviceId(){
    return readStringFromEEPROM(ADDRESS_DEVICE_ID);
}

void Config::setDeviceId(String device_id){
    writeStringToEEPROM(ADDRESS_DEVICE_ID, device_id);
}

String Config::getDeviceName(){
    return readStringFromEEPROM(ADDRESS_DEVICE_NAME);
}

void Config::setDeviceName(String device_name){
    writeStringToEEPROM(ADDRESS_DEVICE_NAME, device_name);
}

int Config::getIpType(){
    return readIntFromEEPROM(ADDRESS_IP_TYPE);
}
void Config::setIpType(int ipType){
    writeIntToEEPROM(ADDRESS_IP_TYPE, ipType);
}

String Config::getIp(){
    return readStringFromEEPROM(ADDRESS_IP);
}

void Config::setIp(String ip){
    writeStringToEEPROM(ADDRESS_IP, ip);
}

String Config::getGateway(){
    return readStringFromEEPROM(ADDRESS_GATEWAY);
}

void Config::setGateway(String gateway){
    writeStringToEEPROM(ADDRESS_GATEWAY, gateway);
}

String Config::getSubnetMask(){
    return readStringFromEEPROM(ADDRESS_SUBNETMASK);
}

void Config::setSubnetMask(String subnetMask){
    writeStringToEEPROM(ADDRESS_SUBNETMASK, subnetMask);
}

String Config::getWifiRouterName(){
    String wifiRouterName = readStringFromEEPROM(ADDRESS_WIFI_ROUTER_NAME);
    if(wifiRouterName == NULL || wifiRouterName.isEmpty()){
        wifiRouterName = AP_SSID;
    }
    return wifiRouterName;
}
void Config::setWifiRouterName(String wifiRouterName){
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_NAME, wifiRouterName);
}

String Config::getWifiRouterIp(){
    String wifiRouterIp = readStringFromEEPROM(ADDRESS_WIFI_ROUTER_IP);
    if(wifiRouterIp == NULL || wifiRouterIp.isEmpty()){
        wifiRouterIp = AP_IP_ADDRESS;
    }
    return wifiRouterIp;
}
void Config::setWifiRouterIp(String wifiRouterIp){
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_IP, wifiRouterIp);
}

String Config::getWifiRouterPassword(){
    String wifiRouterPassword = readStringFromEEPROM(ADDRESS_WIFI_ROUTER_PASSWORD);
    if(wifiRouterPassword == NULL || wifiRouterPassword.isEmpty()){
        wifiRouterPassword = AP_PASWORD;
    }
    return wifiRouterPassword;
}
void Config::setWifiRouterPassword(String wifiRouterPassword){
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_PASSWORD, wifiRouterPassword);
}

String Config::getWifiRouterGateway(){
    String wifiRouterGateway = readStringFromEEPROM(ADDRESS_WIFI_ROUTER_GATEWAY);
    if(wifiRouterGateway == NULL || wifiRouterGateway.isEmpty()){
        wifiRouterGateway = AP_GATEWAY;
    }
    return wifiRouterGateway;
}
void Config::setWifiRouterGateway(String wifiRouterGateway){
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_GATEWAY, wifiRouterGateway);
}

String Config::getWifiRouterSubnetmask(){
    String wifiRouterSubnetmask = readStringFromEEPROM(ADDRESS_WIFI_ROUTER_SUBNETMASK);
    if(wifiRouterSubnetmask == NULL || wifiRouterSubnetmask.isEmpty()){
        wifiRouterSubnetmask = AP_SUBNETMASK;
    }
    return wifiRouterSubnetmask;
}
void Config::setWifiRouterSubnetmask(String wifiRouterSubnetmask){
    writeStringToEEPROM(ADDRESS_WIFI_ROUTER_SUBNETMASK, wifiRouterSubnetmask);
}


int Config::getCurDistance(){
    return readIntFromEEPROM(ADDRESS_CUR_DISTANCE);
}
void Config::setCurDistance(int curDistance){
    writeIntToEEPROM(ADDRESS_CUR_DISTANCE, curDistance);
}

int Config::getCoXe(){
    return readIntFromEEPROM(ADDRESS_CO_XE);
}
void Config::setCoXe(int coXe){
    writeIntToEEPROM(ADDRESS_CO_XE, coXe);
}

int Config::getTgBatDauDauXe(){
    return readIntFromEEPROM(ADDRESS_TG_DAU_XE);
}
void Config::setTgBatDauDauXe(int tg_dau_xe){
    writeIntToEEPROM(ADDRESS_TG_DAU_XE, tg_dau_xe);
}

int Config::getTgKetThucDauXe(){
    return readIntFromEEPROM(ADDRESS_TG_KET_THUC_DAU_XE);
}
void Config::setTgKetThucDauXe(int tg_ket_thuc_dau_xe){
    writeIntToEEPROM(ADDRESS_TG_KET_THUC_DAU_XE, tg_ket_thuc_dau_xe);
}

int Config::getSoPhutDauXe(){
    return readIntFromEEPROM(ADDRESS_SO_PHUT_DAU_XE);
}
void Config::setSoPhutDauXe(int cosoPhutDauXe){
    writeIntToEEPROM(ADDRESS_SO_PHUT_DAU_XE, cosoPhutDauXe);
}

int Config::getCanhBao(){
    return readIntFromEEPROM(ADDRESS_CANH_BAO);
}
void Config::setCanhBao(int canhBao){
    writeIntToEEPROM(ADDRESS_CANH_BAO, canhBao);
}

String Config::getHistory(){
    return readStringFromEEPROM(ADDRESS_HISTORY);
}

void Config::addHistory(String date, String text){
    String history = readStringFromEEPROM(ADDRESS_HISTORY);
    if(!getHistoryDate().equalsIgnoreCase(date)){
        history = history + ";" + "date:" + date + ";" + text;
    }else{
        history = history + ";" + text;
    }

    if(history.length() > MAX_LENGTH_HISTORY){
        int overLength = history.length() - MAX_LENGTH_HISTORY;
        int pos = 0;
        while(pos < overLength){
            pos = history.indexOf(';', pos + 1);
        }
        history = history.substring(pos);
    }
    
    writeStringToEEPROM(ADDRESS_HISTORY, history);
    writeStringToEEPROM(ADDRESS_HISTORY_DATE, date);
}

void Config::clearHistory(){
    writeStringToEEPROM(ADDRESS_HISTORY, "");
    writeStringToEEPROM(ADDRESS_HISTORY_DATE, "");
}

void Config::writeIntToEEPROM(int address, int data)
{
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false);
    preferences.putInt(String(address).c_str(), data);
    preferences.end();
}

int Config::readIntFromEEPROM(int address)
{
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false); // Mở NVS với tên namespace là "config"
    int value = preferences.getInt(String(address).c_str(), 0);
    preferences.end();
    return value;
}

void Config::writeLongToEEPROM(int address, long data)
{
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false);
    preferences.putLong(String(address).c_str(), data);
    preferences.end();
}

long Config::readLongFromEEPROM(long address)
{
    Preferences preferences;
    preferences.begin(NVS_NAMESPACE, false); // Mở NVS với tên namespace là "config"
    int value = preferences.getLong(String(address).c_str(), 0);
    preferences.end();
    return value;
}

String Config::getHistoryDate(){
    return readStringFromEEPROM(ADDRESS_HISTORY_DATE); 
}
void Config::setHistoryDate(String date){
    writeStringToEEPROM(ADDRESS_HISTORY_DATE, date);
}


int Config::getTest(){
    return readIntFromEEPROM(ADDRESS_TEST_TYPE);
}
void Config::setTest(int test){
    writeIntToEEPROM(ADDRESS_TEST_TYPE, test);
}