#include "webserver.h"

// HTML for the login page
const char* loginPage = "<!DOCTYPE html>\
<html>\
<head>\
<meta http-equiv='X-UA-Compatible' content='IE=8, IE=9, IE=10' >\
<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>\
<title>Login</title>\
<link rel='stylesheet' href='/style.css' />\
</head>\
<body>\
<center>\
<div class='logo'>&nbsp;</div>\
<div class='header_title'>gmcom.asia/ Professional software developer</div>\
</center>\
<form action='/login' method='post'>\
    <center>\
        <div class='login-form'>\
            <h2>Login</h2>\
            Username:<br>\
            <input type='text' name='username'><br>\
            Password:<br>\
            <input type='password' name='password'><br><br>\
            <input type='submit' value='Submit'>\
        </div>\
    </center>\
</form>\
</body>\
</html>";

String generateShortUUID() {
  const char characters[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  const int length = 8;
  String uuid = "";

  for (int i = 0; i < length; i++) {
    int randomIndex = random(0, strlen(characters));
    uuid += characters[randomIndex];
  }

  return uuid;
}
// Hàm để tạo và quản lý session
String SHWebServer::createSession(String userId) {
    String sessionId = generateShortUUID();
    preferences.begin("session", false);
    preferences.putString(sessionId.c_str(), userId);
    preferences.end();
    Serial.print("userId:");
    Serial.println(userId);
    Serial.print("sessionId:");
    Serial.println(sessionId);
    return sessionId;
}

String SHWebServer::getUserIdFromSession(String sessionId) {
    preferences.begin("session", true);
    String userId = preferences.getString(sessionId.c_str(), "");
    preferences.end();
    Serial.print("userId:");
    Serial.println(userId);
    return userId;
}

void replaceSubstring(char* str, const char* oldStr, const char* newStr) {
    char* ptr = strstr(str, oldStr); // Find the first occurrence of oldStr in str
    if (ptr != NULL) {
        size_t oldLen = strlen(oldStr);
        size_t newLen = strlen(newStr);
        size_t strLen = strlen(str);
        
        if (newLen > oldLen) { // If the new substring is longer than the old one
            memmove(ptr + newLen, ptr + oldLen, strLen - (ptr - str) - oldLen + 1); // Move the remaining characters to make space for the new substring
        } else if (newLen < oldLen) { // If the new substring is shorter than the old one
            memmove(ptr + newLen, ptr + oldLen, strLen - (ptr - str) - oldLen + 1); // Move the remaining characters to remove the extra characters
        }
        
        memcpy(ptr, newStr, newLen); // Copy the new substring into the original string
    }
}

String SHWebServer::getCookie(String header, String name) {
    int start = header.indexOf(name + "=");
    if (start == -1) return "";
    start += name.length() + 1;
    int end = header.indexOf(';', start);
    if (end == -1) end = header.length();
    return header.substring(start, end);
}

boolean SHWebServer::isAuth(){
    String sessionId = server.arg("sessionId");
    Serial.print("sessionId: ");
    Serial.println(sessionId);
    if (sessionId.length() > 0) {
        String userId = getUserIdFromSession(sessionId);
        if (userId.length() > 0) {
            if(config.getLoginId() != NULL && !config.getLoginId().isEmpty()){
                if(userId == config.getLoginId()){
                    return true;
                }
            }else if(userId == "admin"){
                return true;
            }
        }
    }
    return false;
}

void SHWebServer::init() {
    config.init();
    // Initialize the I2C communication
    Wire.begin();
    
    // Initialize the RTC
    if (!m_rtc.begin()) {
        Serial.println("Couldn't find RTC");
    }
}

void SHWebServer::handleRoot() {
    Serial.println("handleRoot.");
    String header = server.header("Cookie");
    String sessionId = getCookie(header, "SESSION_ID");

    Serial.print("header:");
    Serial.println(header);
    Serial.print("sessionId:");
    Serial.println(sessionId);
    if (sessionId.length() > 0) {
        String userId = getUserIdFromSession(sessionId);
        if (userId.length() > 0) {
            if(config.getLoginId() != NULL && !config.getLoginId().isEmpty()){
                if(userId == config.getLoginId()){
                    server.send(200, "text/html; charset=utf-8", showMainPage(sessionId));
                    return;
                }
            }else if(userId == "admin"){
                server.send(200, "text/html; charset=utf-8", showMainPage(sessionId));
                return;
            }
        }
    }

    server.send(200, "text/html", loginPage);
}

void SHWebServer::handleLogin() {
    Serial.println("handleLogin.");
    String username = server.arg("username");
    String password = server.arg("password");
    Serial.print("username: ");
    Serial.println(username);
    Serial.print("password: ");
    Serial.println(password);
    Serial.print("login id: ");
    Serial.println(config.getLoginId());
    Serial.print("login password: ");
    Serial.println(config.getLoginPassword());

    // Perform authentication (replace with your own logic)
    if ((config.getLoginId() == NULL || config.getLoginId().isEmpty()) && (config.getLoginPassword() == NULL || config.getLoginPassword().isEmpty()) && username == "admin" && password == "admin") {
        String sessionId = createSession(username);
        server.sendHeader("Set-Cookie", "SESSION_ID=" + sessionId + "; Max-Age=3600; HttpOnly");
        server.send(200, "text/html; charset=utf-8", showMainPage(sessionId));
        preferences.end();
    }else if (username == config.getLoginId() && password == config.getLoginPassword()) {
        String sessionId = createSession(username);
        server.sendHeader("Set-Cookie", "SESSION_ID=" + sessionId + "; Max-Age=3600; HttpOnly");
        server.send(200, "text/html; charset=utf-8", showMainPage(sessionId));
    } else {
        server.send(401, "text/plain", "Unauthorized");
    }
}

void SHWebServer::handleLogout(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    // Xóa session ID khỏi Preferences
    preferences.begin("session", false);
    preferences.remove(sessionId.c_str());
    preferences.end();
    server.send(200, "text/html", loginPage);
}

void SHWebServer::handleRestart(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    //config.setBootMode(BOOT_MODE_NORMAL);
    ESP.restart();
}

String SHWebServer::htmlEncode(String str) {
    String encodedStr = "";
    for (char ch : str) {
        switch (ch) {
            case '&':
                encodedStr += "&amp;";
                break;
            case '<':
                encodedStr += "&lt;";
                break;
            case '>':
                encodedStr += "&gt;";
                break;
            case '"':
                encodedStr += "&quot;";
                break;
            case '\'':
                encodedStr += "&#39;";
                break;
            default:
                encodedStr += ch;
                break;
        }
    }
    return encodedStr;
}

void SHWebServer::handleMainJS(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    String rep = "";

    rep += "var m_DeviceId = '" + config.getDeviceId() + "';\n";
    rep += "var m_SSID = '" + config.getSSID() + "';\n";
    rep += "var m_Password = '" + config.getPassword() + "';\n";
    rep += "var m_LoginId = '" + config.getLoginId() + "';\n";
    rep += "var m_LoginPassword = '" + config.getLoginPassword() + "';\n";
    rep += "var m_MinDistance = '" + String(config.getMinDistance()) + "';\n";
    rep += "var m_MaxDistance = '" + String(config.getMaxDistance()) + "';\n";

    rep += "var m_DeviceName = '" + config.getDeviceName() + "';\n";
    rep += "var m_IpType = '" + String(config.getIpType()) + "';\n";
    rep += "var IP_TYPE_MANUAL = '1';\n";

    rep += "var m_Ip = '" + config.getIp() + "';\n";
    rep += "var m_Gateway = '" + config.getGateway() + "';\n";
    rep += "var m_SubnetMask = '" + config.getSubnetMask() + "';\n";
    rep += "var sessionId='" + sessionId + "';\n";

    rep += Utils::readFile("/js/main.js");

    rep += scanWiFiNetworks();

    size_t contentLength = rep.length();
    Serial.print("Javascript length: ");
    Serial.println(contentLength);

    server.sendHeader("Content-Length", String(contentLength));
    server.send(200, "text/javascript; charset=utf-8", rep);
}

void SHWebServer::handleMain2JS(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    String rep = "";

    rep += scanWiFiNetworks();

    size_t contentLength = rep.length();
    Serial.print("Javascript length: ");
    Serial.println(contentLength);

    server.sendHeader("Content-Length", String(contentLength));
    server.send(200, "text/javascript; charset=utf-8", rep);
}

void SHWebServer::handleMainMenuJS(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    String rep = "";

    rep += "var sessionId='" + sessionId + "';\n";
    rep += "var m_BootMode='" + String(config.getBootMode()) + "';\n";
    
    rep += Utils::readFile("/js/mainMenu.js");

    size_t contentLength = rep.length();
    Serial.print("Javascript length: ");
    Serial.println(contentLength);

    server.sendHeader("Content-Length", String(contentLength));
    server.send(200, "text/javascript; charset=utf-8", rep);
}

void SHWebServer::handleWifiRouterJS(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    String rep = "";
    rep += "var wifiRouterName = '" + config.getWifiRouterName() + "';\n";
    rep += "var wifiRouterIp = '" + config.getWifiRouterIp() + "'\n";
    rep += "var wifiRouterPassword = '" + config.getWifiRouterPassword() + "';\n";
    rep += "var wifiRouterGateway = '" + config.getWifiRouterGateway() + "';\n";
    rep += "var wifiRouterSubnetmask = '" + config.getWifiRouterSubnetmask() + "';\n";
    rep += "var AP_SSID = '" + String(AP_SSID) + "';\n";
    rep += "var AP_IP_ADDRESS = '" + String(AP_IP_ADDRESS) + "';\n";
    rep += "var AP_PASWORD = '" + String(AP_PASWORD) + "';\n";
    rep += "var AP_GATEWAY = '" + String(AP_GATEWAY) + "';\n";
    rep += "var AP_SUBNETMASK = '" + String(AP_SUBNETMASK) + "';\n";
    rep += "var sessionId='" + sessionId + "';\n";

    rep += Utils::readFile("/js/wifiRouter.js");

    size_t contentLength = rep.length();
    Serial.print("Javascript length: ");
    Serial.println(contentLength);

    server.sendHeader("Content-Length", String(contentLength));
    server.send(200, "text/javascript; charset=utf-8", rep);
}

void SHWebServer::handleMyApplicationJS(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    String rep = "";
    rep += "var my_app_name = '" + config.getDeviceName() + "(" + config.getWifiRouterName() + ")';\n";
    rep += "var my_app_ip = '" + config.getWifiRouterIp() + "'\n";
    rep += "var my_app_min_distance = '" + String(config.getMinDistance()) + "';\n";
    rep += "var my_app_max_distance = '" + String(config.getMaxDistance()) + "';\n";
    rep += "var my_app_max_minute = '" + String(config.getMaxMinute()) + "';\n";
    rep += "var my_app_max_wait_seconds = '" + String(config.getMaxWaitSeconds()) + "';\n";

    rep += "var sessionId='" + sessionId + "';\n";

    rep += Utils::readFile("/js/myApplication.js");

    size_t contentLength = rep.length();
    Serial.print("Javascript length: ");
    Serial.println(contentLength);

    server.sendHeader("Content-Length", String(contentLength));
    server.send(200, "text/javascript; charset=utf-8", rep);
}


String SHWebServer::scanWiFiNetworks() {
    String rep = "";

    int numNetworks = WiFi.scanNetworks();
    Serial.println("Number of networks found: " + String(numNetworks));

    rep += "var select = document.getElementById('ssid');\n";
    rep += "var opt;\n";
    rep += "opt = document.createElement('option');\n";
    rep += "opt.innerHTML = '" + htmlEncode(config.getSSID()) + "';\n";
    rep += "select.appendChild(opt);\n";

    for (int i = 0; i < numNetworks; i++) {
        String wName = WiFi.SSID(i);
        int32_t rssi = WiFi.RSSI(i);
        rep += "opt = document.createElement('option');\n";
        rep += "opt.value = '" + htmlEncode(wName) + "';\n";
        rep += "opt.innerHTML = '" + htmlEncode(wName) + " (" + rssi + " dBm)';\n";
        rep += "select.appendChild(opt);\n";
        Serial.println(wName);
    }
    rep += "select.value = '" + config.getSSID() + "';\n";

    return rep;
}

void SHWebServer::handleWifiRefresh(){
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    // Hiển thị danh sách mạng WiFi trong phạm vi
    int numNetworks = WiFi.scanNetworks();
    Serial.println("Number of networks found: " + String(numNetworks));
    
    String rep = "";
    rep += "<select id='ssid' name='ssid'>";
    rep += "<option value='' selected>" + config.getSSID() + "</option>";

    // In ra tên của các mạng WiFi đã quét được
    for (int i = 0; i < numNetworks; i++) {
        String wName = WiFi.SSID(i);
        int32_t rssi = WiFi.RSSI(i);
        rep += "<option value = '" + wName + "'>";
        rep += wName + " (" + rssi + " dBm)";
        rep += "</option>";
        Serial.println(wName);
    }
    rep += "</select>";

    Serial.print("Combo wifi length: ");
    Serial.println(rep.length());
    server.send(200, "text/text; charset=utf-8", rep);
}

void SHWebServer::handleMainPage(){
    Serial.println("handleMainPage.");
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    server.send(200, "text/html", showMainPage(sessionId));
}

void SHWebServer::handleMyWifiRouter(){
    Serial.println("handleMyWifiRouter.");
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }

    String sessionId = server.arg("sessionId");
    server.send(200, "text/html", showMyWifiRouter(sessionId));
}

void SHWebServer::handleUpdateFW(){
    if(!isSystemAuth()){
        server.send(200, "text/html", "Permission denied");
        return;
    }
    config.setBootMode(BOOT_MODE_UPDATE_FW);
    ESP.restart();
}

void SHWebServer::handleUpdateFileSystem(){
    if(!isSystemAuth()){
        server.send(200, "text/html", "Permission denied");
        return;
    }
    config.setBootMode(BOOT_MODE_UPDATE_FILESYSTEM);
    ESP.restart();
}

void SHWebServer::handleKetNoiWifiRouter(){
    Serial.println("handleKetNoiWifiRouter.");
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    server.send(200, "text/html", showSettingPage(sessionId));
}

void SHWebServer::handleMyApplication(){
    Serial.println("handleMyApplication.");
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String sessionId = server.arg("sessionId");
    server.send(200, "text/html", showMyApplicationPage(sessionId));
}

void SHWebServer::handleSaveSetting(){
    Serial.println("handleSaveSetting.");
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String username = server.arg("username");
    String password = server.arg("password");

    String ssid = server.arg("ssid");
    String ssid_password = server.arg("ssid_password");

    String min_distance = server.arg("min_distance");
    String max_distance = server.arg("max_distance");
    String login_id = server.arg("login_id");
    String login_password = server.arg("login_password");

    String ipType = server.arg("ipType");
    String ipAddress = server.arg("ipAddress");
    String gateway = server.arg("gateway");
    String subnetMask = server.arg("subnet");

    String name = server.arg("name");

    config.setSSID(ssid);
    config.setPassword(ssid_password);

    config.setMinDistance(min_distance.toInt());
    config.setMaxDistance(max_distance.toInt());

    config.setLoginId(login_id);
    config.setLoginPassword(login_password);

    config.setDeviceName(name);

    if(ipType.equals("manual-ip")){
        config.setIpType(IP_TYPE_MANUAL);
        config.setIp(ipAddress);
        config.setGateway(gateway);
        config.setSubnetMask(subnetMask);
    }else{
        config.setIpType(IP_TYPE_DHCP);
    }

    //config.setBootMode(BOOT_MODE_NORMAL);
    config.setInitialized();

    Serial.print("login id: ");
    Serial.println(config.readStringFromEEPROM(ADDRESS_LOGIN_ID));

    Serial.print("login password: ");
    Serial.println(config.readStringFromEEPROM(ADDRESS_LOGIN_PASSWORD));

    Serial.print("BOOT_MODE: ");
    Serial.println(config.readStringFromEEPROM(ADDRESS_BOOT_MODE));

    Serial.print("INIT_STATE: ");
    Serial.println(config.readStringFromEEPROM(ADDRESS_INIT_STATE));

    ESP.restart();
}

void SHWebServer::handleMyWifiRouterSave(){
    Serial.println("handleMyWifiRouterSave.");
    if(!isAuth()){
        server.send(200, "text/html", loginPage);
        return;
    }
    String wifiRouterName = server.arg("wifi_router_name");
    String wifiRouterIp = server.arg("wifi_router_ip");
    String wifiRouterPassword = server.arg("wifi_router_password");
    String wifiRouterGateway = server.arg("wifi_router_gateway");
    String wifiRouterSubnetmask = server.arg("wifi_router_subnetmask");

    config.setWifiRouterName(wifiRouterName);
    config.setWifiRouterIp(wifiRouterIp);
    config.setWifiRouterPassword(wifiRouterPassword);
    config.setWifiRouterGateway(wifiRouterGateway);
    config.setWifiRouterSubnetmask(wifiRouterSubnetmask);

    ESP.restart();
}

void SHWebServer::router(){
    server.on("/", HTTP_GET,  std::bind(&SHWebServer::handleRoot, this));
    // Route for login form submission
    server.on("/login", HTTP_POST, std::bind(&SHWebServer::handleLogin, this));
    // Route for save setting form submission
    server.on("/saveSetting", HTTP_POST, std::bind(&SHWebServer::handleSaveSetting, this));
    server.on("/restart", HTTP_GET, std::bind(&SHWebServer::handleRestart, this));
    server.on("/wifiRefresh", HTTP_POST, std::bind(&SHWebServer::handleWifiRefresh, this));
    server.on("/mainPage", HTTP_GET, std::bind(&SHWebServer::handleMainPage, this));
    server.on("/myWifiRouter", HTTP_GET, std::bind(&SHWebServer::handleMyWifiRouter, this));
    server.on("/ketNoiWifiRouter", HTTP_GET, std::bind(&SHWebServer::handleKetNoiWifiRouter, this));
    server.on("/logout", HTTP_GET, std::bind(&SHWebServer::handleLogout, this));
    server.on("/myWifiRoutersave", HTTP_POST, std::bind(&SHWebServer::handleMyWifiRouterSave, this));
    server.on("/setDateTime", HTTP_POST, std::bind(&SHWebServer::handleSetDateTime, this));
    server.on("/about", HTTP_GET, std::bind(&SHWebServer::handleAboutPage, this));

    //update 
    server.on("/updateFW", HTTP_POST, std::bind(&SHWebServer::handleUpdateFW, this));
    server.on("/updateFileSystem", HTTP_POST, std::bind(&SHWebServer::handleUpdateFileSystem, this));
    
    //css
    server.on("/style.css", HTTP_GET, std::bind(&SHWebServer::handleStyleCSS, this));

    //js
    server.on("/main.js", HTTP_GET, std::bind(&SHWebServer::handleMainJS, this));
    server.on("/main2.js", HTTP_GET, std::bind(&SHWebServer::handleMain2JS, this));
    server.on("/mainMenu.js", HTTP_GET, std::bind(&SHWebServer::handleMainMenuJS, this));
    server.on("/wifiRouter.js", HTTP_GET, std::bind(&SHWebServer::handleWifiRouterJS, this));
    server.on("/myApplication.js", HTTP_GET, std::bind(&SHWebServer::handleMyApplicationJS, this));

    //normal mode only
    server.on("/myApplication", HTTP_GET, std::bind(&SHWebServer::handleMyApplication, this));
    
    server.on("/logo.jpg", HTTP_GET, std::bind(&SHWebServer::handleLogoJPG, this));
    server.on("/jquery.js", HTTP_GET, std::bind(&SHWebServer::handleJqueryJS, this));
    server.on("/favicon.ico", HTTP_GET, std::bind(&SHWebServer::handleFaviconICO, this));

    
    server.on("/getSensorInfo", HTTP_POST, std::bind(&SHWebServer::handleGetSensorInfo, this));
    server.on("/saveSensorInfo", HTTP_POST, std::bind(&SHWebServer::handleSaveSensorInfo, this));
    
    // test only
    server.on("/test", HTTP_POST,  std::bind(&SHWebServer::handleTest, this));
}

void SHWebServer::startAccessPoint(){
    //Serial.begin(9600);

    String apSSID;
    String apPassword;
    // Fixed IP address for the ESP32
    if(config.getWifiRouterIp() != NULL && !config.getWifiRouterIp().isEmpty()){
        int parts[4];
        // Phân tích chuỗi địa chỉ IP
        Utils::parseIPString(config.getWifiRouterIp(), parts);
        IPAddress ip(parts[0], parts[1], parts[2], parts[3]); 

        Utils::parseIPString(config.getWifiRouterGateway(), parts);
        IPAddress gateway(parts[0], parts[1], parts[2], parts[3]);

        Utils::parseIPString(config.getWifiRouterSubnetmask(), parts);
        IPAddress subnet(parts[0], parts[1], parts[2], parts[3]); 

        // Set up Access Point with fixed IP
        WiFi.softAPConfig(ip, gateway, subnet);
        apSSID = config.getWifiRouterName();
        apPassword = config.getWifiRouterPassword();
    }else{
        IPAddress ip(192, 168, 69, 70);  // Change this to your desired fixed IP address
        IPAddress gateway(192, 168, 69, 1);
        IPAddress subnet(255, 255, 255, 0); 

        // Set up Access Point with fixed IP
        WiFi.softAPConfig(ip, gateway, subnet);
        apSSID = AP_SSID;
        apPassword = AP_PASWORD;
    }

    

    // Set up Access Point
    if (!WiFi.softAP(apSSID, apPassword)) {
      Serial.println("Soft AP creation failed.");
      while(1);
    }
    Serial.println("Access Point Started");
    Serial.print("IP Address: ");
    Serial.println(WiFi.softAPIP());

    /*// Route for root / web page
    server.on("/", HTTP_GET,  std::bind(&SHWebServer::handleRoot, this));
    // Route for login form submission
    server.on("/login", HTTP_POST, std::bind(&SHWebServer::handleLogin, this));
    // Route for save setting form submission
    server.on("/saveSetting", HTTP_POST, std::bind(&SHWebServer::handleSaveSetting, this));
    server.on("/restart", HTTP_GET, std::bind(&SHWebServer::handleRestart, this));
    server.on("/wifiRefresh", HTTP_POST, std::bind(&SHWebServer::handleWifiRefresh, this));
    server.on("/mainPage", HTTP_GET, std::bind(&SHWebServer::handleMainPage, this));
    server.on("/myWifiRouter", HTTP_GET, std::bind(&SHWebServer::handleMyWifiRouter, this));
    server.on("/ketNoiWifiRouter", HTTP_GET, std::bind(&SHWebServer::handleKetNoiWifiRouter, this));
    server.on("/logout", HTTP_GET, std::bind(&SHWebServer::handleLogout, this));
    server.on("/myWifiRoutersave", HTTP_POST, std::bind(&SHWebServer::handleMyWifiRouterSave, this));
    
    //css
    server.on("/style.css", HTTP_GET, std::bind(&SHWebServer::handleStyleCSS, this));

    //js
    server.on("/main.js", HTTP_GET, std::bind(&SHWebServer::handleMainJS, this));
    server.on("/mainMenu.js", HTTP_GET, std::bind(&SHWebServer::handleMainMenuJS, this));
    server.on("/wifiRouter.js", HTTP_GET, std::bind(&SHWebServer::handleWifiRouterJS, this));
    server.on("/myApplication.js", HTTP_GET, std::bind(&SHWebServer::handleMyApplicationJS, this));

    server.on("/logo.jpg", HTTP_GET, std::bind(&SHWebServer::handleLogoJPG, this));
    server.on("/jquery.js", HTTP_GET, std::bind(&SHWebServer::handleJqueryJS, this));
    server.on("/favicon.ico", HTTP_GET, std::bind(&SHWebServer::handleFaviconICO, this));
*/
    router();

    // Start server
    server.begin();
    Serial.println("HTTP server started");
}

void SHWebServer::startWebServer(){
    /*// Route for root / web page
    server.on("/", HTTP_GET,  std::bind(&SHWebServer::handleRoot, this));
    // Route for login form submission
    server.on("/login", HTTP_POST, std::bind(&SHWebServer::handleLogin, this));
    // Route for save setting form submission
    server.on("/saveSetting", HTTP_POST, std::bind(&SHWebServer::handleSaveSetting, this));
    server.on("/restart", HTTP_GET, std::bind(&SHWebServer::handleRestart, this));
    server.on("/wifiRefresh", HTTP_POST, std::bind(&SHWebServer::handleWifiRefresh, this));
    server.on("/mainPage", HTTP_GET, std::bind(&SHWebServer::handleMainPage, this));
    server.on("/myWifiRouter", HTTP_GET, std::bind(&SHWebServer::handleMyWifiRouter, this));
    server.on("/ketNoiWifiRouter", HTTP_GET, std::bind(&SHWebServer::handleKetNoiWifiRouter, this));
    server.on("/logout", HTTP_GET, std::bind(&SHWebServer::handleLogout, this));
    server.on("/myWifiRoutersave", HTTP_POST, std::bind(&SHWebServer::handleMyWifiRouterSave, this));
    
    //css
    server.on("/style.css", HTTP_GET, std::bind(&SHWebServer::handleStyleCSS, this));

    //js
    server.on("/main.js", HTTP_GET, std::bind(&SHWebServer::handleMainJS, this));
    server.on("/mainMenu.js", HTTP_GET, std::bind(&SHWebServer::handleMainMenuJS, this));
    server.on("/wifiRouter.js", HTTP_GET, std::bind(&SHWebServer::handleWifiRouterJS, this));
    server.on("/myApplication.js", HTTP_GET, std::bind(&SHWebServer::handleMyApplicationJS, this));

    //normal mode only
    server.on("/myApplication", HTTP_GET, std::bind(&SHWebServer::handleMyApplication, this));
    
    server.on("/logo.jpg", HTTP_GET, std::bind(&SHWebServer::handleLogoJPG, this));
    server.on("/jquery.js", HTTP_GET, std::bind(&SHWebServer::handleJqueryJS, this));
    server.on("/favicon.ico", HTTP_GET, std::bind(&SHWebServer::handleFaviconICO, this));
*/
    router();
    // Start server
    server.begin();
    Serial.println("HTTP server started");
    Serial.print("IP Address: ");
    Serial.println(WiFi.softAPIP());
}

void SHWebServer::handleClient(){
    server.handleClient();
}

String SHWebServer::showMainPage(String sessionId){
    String rep = Utils::readFile("/html/mainPage.html");
    rep.replace("\" + sessionId + \"", sessionId);
    Serial.print("Page length: ");
    Serial.println(rep.length());
    return rep;
}

String SHWebServer::showSettingPage(String sessionId){
    String rep = Utils::readFile("/html/settingPage.html");
    rep.replace("\" + sessionId + \"", sessionId);

    Serial.print("Page length: ");
    Serial.println(rep.length());
    return rep;
}

String SHWebServer::showMyWifiRouter(String sessionId){
    String rep = Utils::readFile("/html/myWifiRouter.html");
    rep.replace("\" + sessionId + \"", sessionId);

    Serial.print("Page length: ");
    Serial.println(rep.length());
    return rep;
}

String SHWebServer::showMyApplicationPage(String sessionId){
    String rep = Utils::readFile("/html/myApplicationPage.html");
    rep.replace("\" + sessionId + \"", sessionId);

    Serial.print("Page length: ");
    Serial.println(rep.length());
    return rep;
}

void SHWebServer::handleLogoJPG(){
    serveFile("/img/logo88x88.jpg", "image/jpeg");
}
void SHWebServer::handleJqueryJS(){
    serveFile("/jquery/jquery-3.7.1.min.js", "application/javascript");
}
void SHWebServer::handleFaviconICO(){
    serveFile("/favicon.ico", "image/x-icon");
}

void SHWebServer::handleStyleCSS(){
    serveFile("/css/style.css", "text/css; charset=utf-8");
}

void SHWebServer::serveFile(const String& path, const String& contentType) {
  File file = SPIFFS.open(path, "r");
  if (!file) {
    Serial.println("Failed to open file for reading");
    server.send(404, "text/plain", "File not found");
    return;
  }

  server.streamFile(file, contentType);
  file.close();
}

void SHWebServer::handleGetSensorInfo(){
    Serial.println("handleGetSensorInfo.");
    if(!isAuth()){
        server.send(400, "application/json", "{\"error\":\"Access denied\"}");
        return;
    }
    if (server.hasArg("plain") == false) {
        // Handle error
        server.send(400, "application/json", "{\"error\":\"No JSON payload\"}");
        return;
    }

    String json = server.arg("plain");
    Serial.println("Received JSON: " + json);

    // Parse JSON
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, json);

    if (error) {
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
    }
    // Extract values from JSON
    const char* action = doc["action"];
    int value = doc["value"];

    // Prepare response JSON
    StaticJsonDocument<500> responseDoc;
    responseDoc["status"] = "success";
    if(config.getCoXe() == 1){
        responseDoc["distance"] = config.getCurDistance();
    }else{
        responseDoc["distance"] = m_CurDistance;
    }
    responseDoc["total_time_seconds"] = m_seconds%60;
    responseDoc["kq"] = config.getCoXe();
    responseDoc["from"] = config.getTgBatDauDauXe();
    responseDoc["to"] = config.getTgKetThucDauXe();
    responseDoc["total_time"] = config.getSoPhutDauXe();
    responseDoc["den_canh_bao"] = config.getCanhBao();
    responseDoc["lich_su"] = config.getHistory();
    String response;
    serializeJson(responseDoc, response);

    // Send response
    server.send(200, "application/json", response);
}


void SHWebServer::handleSaveSensorInfo(){
    Serial.println("handleSaveSensorInfo.");
    if(!isAuth()){
        server.send(400, "application/json", "{\"error\":\"Access denied\"}");
        return;
    }
     if (server.hasArg("plain") == false) {
        // Handle error
        server.send(400, "application/json", "{\"error\":\"No JSON payload\"}");
        return;
    }

    String json = server.arg("plain");
    Serial.println("Received JSON: " + json);

    // Parse JSON
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, json);

    if (error) {
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
    }

    // Extract values from JSON
    int my_app_min_distance = doc["my_app_min_distance"];
    int my_app_max_distance = doc["my_app_max_distance"];
    int my_app_max_minute = doc["my_app_max_minute"];
    int my_app_max_wait_seconds = doc["my_app_max_wait_seconds"];

    config.setMinDistance(my_app_min_distance);
    config.setMaxDistance(my_app_max_distance);
    config.setMaxMinute(my_app_max_minute);
    config.setMaxWaitSeconds(my_app_max_wait_seconds);

    // Prepare response JSON
    StaticJsonDocument<500> responseDoc;
    responseDoc["status"] = "success";
    
    String response;
    serializeJson(responseDoc, response);

    // Send response
    server.send(200, "application/json", response);
}

void SHWebServer::handleTest(){
    Serial.println("handlTest.");
    if(!isAuth()){
        server.send(400, "application/json", "{\"error\":\"Access denied\"}");
        return;
    }
    if (server.hasArg("plain") == false) {
        // Handle error
        server.send(400, "application/json", "{\"error\":\"No JSON payload\"}");
        return;
    }

    String json = server.arg("plain");
    Serial.println("Received JSON: " + json);

    // Parse JSON
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, json);

    if (error) {
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
    }
    // Extract values from JSON
    String action = doc["action"];
    int value = doc["value"];

    if(action.equalsIgnoreCase("cur_dist")){
        if(config.getTest() == 1){
            config.setCurDistance(value);
        }   
    }else if(action.equalsIgnoreCase("begin_test")){
        config.setTest(1);
    }else if(action.equalsIgnoreCase("end_test")){
        config.setTest(0);
    }

    // Prepare response JSON
    StaticJsonDocument<500> responseDoc;
    responseDoc["status"] = "success";
    
    String response;
    serializeJson(responseDoc, response);

    // Send response
    server.send(200, "application/json", response);
}

// Function to set the date and time
void SHWebServer::setDateTime(int year, int month, int day, int hour, int minute, int second) {
    // Create a DateTime object with the provided date and time
    DateTime dt(year, month, day, hour, minute, second);
    
    // Set the RTC date and time
    m_rtc.adjust(dt);
}

void SHWebServer::handleSetDateTime(){
    Serial.println("handleSetDateTime.");
    if(!isAuth()){
        server.send(400, "application/json", "{\"error\":\"Access denied\"}");
        return;
    }
    if (server.hasArg("plain") == false) {
        // Handle error
        server.send(400, "application/json", "{\"error\":\"No JSON payload\"}");
        return;
    }

    String json = server.arg("plain");
    Serial.println("Received JSON: " + json);

    // Parse JSON
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, json);

    if (error) {
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
    }
    // Extract values from JSON
    int year = doc["year"];
    int month = doc["month"];
    int day = doc["day"];
    int hour = doc["hour"];
    int minute = doc["minute"];
    int second = doc["second"];

    setDateTime(year, month, day, hour, minute, second);

    // Prepare response JSON
    StaticJsonDocument<500> responseDoc;
    responseDoc["status"] = "success";

    String response;
    serializeJson(responseDoc, response);

    // Send response
    server.send(200, "application/json", response);
}

boolean SHWebServer::isSystemAuth(){
    if (server.hasArg("plain") == false) {
        Serial.println("No has plain");
        return false;
    }

    String json = server.arg("plain");
    Serial.println("Received JSON: " + json);

    // Parse JSON
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, json);

    if (error) {
        return false;
    }
    // Extract values from JSON
    String user = doc["user"];
    String password = doc["password"];
    if(user.equalsIgnoreCase("admin") && password.equals("CP.ESP32@!1234")){
        return true;
    }
    return false;
}

void SHWebServer::setCurDistance(int curDistance){
    m_CurDistance = curDistance;
}

void SHWebServer::setSeconds(int seconds){
    m_seconds = seconds;
}

void SHWebServer::handleAboutPage(){
    Serial.println("handleAboutPage.");
    String rep = Utils::readFile("/html/about.html");
    rep.replace("fsVersion", m_fsVersion);
    rep.replace("fwVersion", m_fwVersion);
    Serial.print("Page length: ");
    Serial.println(rep.length());
    server.send(200, "text/html", rep);
}

void SHWebServer::setVersion(String fsVersion, String fwVersion){
    m_fsVersion = fsVersion;
    m_fwVersion = fwVersion;
}