#ifndef SHWebServer_class_h
#define SHWebServer_class_h
#include <Arduino.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ArduinoJson.h>
#include <WebServer.h>
#include "config/config.h"
#include "utils/utils.h"
#include <Preferences.h>
#include "SPIFFS.h"
#include <ArduinoJson.h>
#include <Wire.h>
#include <RTClib.h>

class SHWebServer
{
public:
    SHWebServer(int port) : server(port) {
    }
    void init();
    void startAccessPoint();
    void startWebServer();
    void handleClient();
    void setCurDistance(int curDistance);
    void setSeconds(int seconds);
    void setVersion(String fsVersion, String fwVersion);
    
private:
    int m_CurDistance = 0;
    int m_seconds = 0;
    WebServer server;
    Preferences preferences;
    Config config;
    String auth = "";
    RTC_DS1307 m_rtc;
    String m_fsVersion = "";
    String m_fwVersion = "";

    void router();

    void handleRoot();
    void handleLogin();
    void handleSaveSetting();
    void handleMyWifiRouterSave();
    void handleRestart();
    void handleWifiRefresh();
    void handleLogout();
    void handleSaveSensorInfo();

    void handleMainPage();

    void handleMyWifiRouter();
    void handleKetNoiWifiRouter();
    void handleMyApplication();

    void handleUpdateFW();
    void handleUpdateFileSystem();

    String htmlEncode(String str);
    String showMainPage(String sessionId);
    String showSettingPage(String sessionId);
    String showMyWifiRouter(String sessionId);
    String showMyApplicationPage(String sessionId);

    String scanWiFiNetworks();

    boolean isAuth();
    String getCookie(String header, String name);
    String createSession(String userId);
    String getUserIdFromSession(String sessionId);
    
    //css
    void handleStyleCSS();

    //js
    void handleMainJS();
    void handleMain2JS();
    void handleMainMenuJS();
    
    void handleWifiRouterJS();

    void handleMyApplicationJS();

    //static file
    void handleLogoJPG();
    void handleJqueryJS();
    void handleFaviconICO();
    void serveFile(const String& path, const String& contentType);
    
    void handleGetSensorInfo();

    void handleTest();

    void handleSetDateTime();
    void setDateTime(int year, int month, int day, int hour, int minute, int second);
    boolean isSystemAuth();

    void handleAboutPage();
};

#endif  // SHWebServer_class_h