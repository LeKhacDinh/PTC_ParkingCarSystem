# micro-miniz

![CI-Badge](https://github.com/rzeldent/micro-miniz/actions/workflows/main.yml/badge.svg?event=push)

Library for encoding and decoding gzip

## Introduction

This library is an encapsulation around the [miniz library](https://code.google.com/archive/p/miniz/).

Only the basic files are included:
- miniz.c
- miniz.h
